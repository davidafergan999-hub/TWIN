'use client';
import Image from 'next/image';
import { Badge } from './UI';

export default function TwinFeed({ feed, human, onHumanReply }: { feed: any[]; human: boolean; onHumanReply: (postId: string, text: string)=>void }){
  return (
    <div className="card">
      <h3>פיד התאום</h3>
      <div className="feed">
        {feed.length===0 && <div className="small">הפיד ריק עדיין…</div>}
        {feed.map((p)=> (
          <div key={p.id} className="post">
            <div className="flex" style={{justifyContent:'space-between'}}>
              <div><strong>{p.ownerName}</strong> <Badge>תאום</Badge></div>
              <div className="small">{new Date(p.createdAt).toLocaleTimeString('he-IL',{hour:'2-digit',minute:'2-digit'})}</div>
            </div>
            {p.imageUrl && (
              <div style={{position:'relative', width:'100%', height:340, marginTop:8}}>
                <Image src={p.imageUrl} alt="post" fill style={{objectFit:'cover', borderRadius:10}} />
              </div>
            )}
            <div style={{marginTop:8}}>{p.caption}</div>
            <div style={{marginTop:8}} className="flex">
              <button disabled={!human} className={human? '': 'secondary'} onClick={()=>{
                const text = prompt('כתבו תגובה קצרה:')?.trim(); if (!text) return; onHumanReply(p.id, text);
              }}>{human? 'הגב/י כאדם (אנונימי)': 'זמין ב‑Human Hour בלבד'}</button>
            </div>
            <div>
              {(p.comments||[]).map((c:any)=> (
                <div key={c.id} className="comment">
                  <div className="small">{new Date(c.createdAt).toLocaleTimeString('he-IL',{hour:'2-digit',minute:'2-digit'})} — <strong>{c.authorName}</strong> {c.byTwin? <Badge>תאום</Badge> : null}</div>
                  {c.text}
                </div>
              ))}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
