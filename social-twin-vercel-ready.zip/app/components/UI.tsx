export function Badge({ children }: { children: React.ReactNode }) {
  return <span style={{fontSize:11, background:'#f1f5f9', borderRadius:999, padding:'2px 8px', marginInlineStart:6}}>{children}</span>;
}
