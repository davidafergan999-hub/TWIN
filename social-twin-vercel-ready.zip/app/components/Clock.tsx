'use client';
import { useEffect, useMemo, useState } from 'react';

export default function Clock({ start = '20:00', durationMin = 60 }: { start?: string; durationMin?: number }) {
  const [now, setNow] = useState<Date>(new Date());
  useEffect(()=>{ const id = setInterval(()=>setNow(new Date()), 1000); return ()=>clearInterval(id); },[]);

  const { inWindow, nextStart, remaining } = useMemo(()=>{
    const [h,m] = start.split(':').map(Number);
    const todayStart = new Date(now); todayStart.setHours(h, m, 0, 0);
    const todayEnd = new Date(todayStart.getTime() + durationMin*60000);
    let inWindow = now >= todayStart && now <= todayEnd;
    let nextStart = todayStart;
    if (now > todayEnd) { nextStart = new Date(todayStart.getTime() + 24*3600*1000); }
    const remaining = inWindow ? Math.max(0, todayEnd.getTime() - now.getTime()) : Math.max(0, nextStart.getTime() - now.getTime());
    return { inWindow, nextStart, remaining };
  },[now, start, durationMin]);

  const fmt = (ms:number)=>{ const s=Math.floor(ms/1000); const h=Math.floor(s/3600); const m=Math.floor((s%3600)/60); const sec=s%60; return `${String(h).padStart(2,'0')}:${String(m).padStart(2,'0')}:${String(sec).padStart(2,'0')}`; };

  return (
    <div className="clock">
      <div className="time">השעה המקומית שלך: {now.toLocaleTimeString('he-IL',{hour:'2-digit',minute:'2-digit',second:'2-digit'})}</div>
      {inWindow ? (
        <div className="window">Human Hour פתוח לעוד {fmt(remaining)}</div>
      ) : (
        <div className="window">Human Hour ייפתח ב‑{nextStart.toLocaleTimeString('he-IL',{hour:'2-digit',minute:'2-digit'})} (בעוד {fmt(remaining)})</div>
      )}
    </div>
  );
}
