import { put } from '@vercel/blob';
export const runtime = 'nodejs';

export async function POST(req: Request) {
  const form = await req.formData();
  const file = form.get('file') as File | null;
  if (!file) return new Response('no file', { status: 400 });
  const ab = await file.arrayBuffer();
  const blob = await put(`uploads/${Date.now()}-${file.name}`, Buffer.from(ab), { access: 'public', addRandomSuffix: true });
  return Response.json({ url: blob.url });
}
