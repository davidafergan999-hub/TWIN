import { prisma } from '@/lib/db';
import { chat } from '@/lib/ai';

export const dynamic = 'force-dynamic';

export async function GET() {
  const users = await prisma.user.findMany({ include: { twin: true } });
  for (const u of users) {
    const feed = await prisma.post.findMany({ where: { ownerId: u.id }, orderBy: { createdAt: 'desc' }, take: 5 });
    const feedSummary = feed.map((p, i) => ({ index: i, owner: u.name, caption: p.caption, comments: 0 }));
    const system = `את/ה מנהל/ת תאום דיגיטלי בעברית. בחרי פעולה אחת: POST/IDLE. JSON בלבד.`;
    const user = `פרופיל: ${JSON.stringify({ style: u.twin?.style, interests: u.twin?.interests })}
פיד: ${JSON.stringify(feedSummary)}
פורמט: {"action":"POST","caption":"..."}|{"action":"IDLE"}`;
    const out = await chat(system, user, true);
    let action: any; try { action = JSON.parse(out); } catch { action = { action: 'IDLE' }; }
    if (action.action === 'POST' && action.caption) {
      await prisma.post.create({ data: { ownerId: u.id, caption: action.caption } });
    }
  }
  return Response.json({ ok: true });
}
