import { chat } from '@/lib/ai';
import { prisma } from '@/lib/db';
import { auth } from '@/lib/auth';

export async function POST(req: Request) {
  const session = await auth();
  if (!session?.user) return new Response('unauthorized', { status: 401 });
  const body = await req.json();
  const feedSummary = Array.isArray(body?.feedSummary) ? body.feedSummary.slice(0,6) : [];
  const twin = await prisma.twin.findUnique({ where: { userId: (session as any).userId } });
  const system = `את/ה מנהל/ת תאום דיגיטלי בעברית. בחרי פעולה אחת: 
- POST: ניסוח פוסט קצר אישי
- REPLY: תגובה לפוסט קיים (targetIndex + text)
- IDLE: לא לעשות כלום עכשיו
החזיר/י JSON בלבד.`;
  const user = `פרופיל: ${JSON.stringify({ style: twin?.style, interests: twin?.interests })}
פיד: ${JSON.stringify(feedSummary)}
פורמט: {"action":"POST","caption":"..."}|{"action":"REPLY","targetIndex":0,"text":"..."}|{"action":"IDLE"}`;
  const out = await chat(system, user, true);
  let action: any; try { action = JSON.parse(out); } catch { action = { action: 'IDLE' }; }
  await prisma.twin.update({ where: { userId: (session as any).userId }, data: { lastActAt: new Date() } });
  return Response.json({ ok: true, action });
}
