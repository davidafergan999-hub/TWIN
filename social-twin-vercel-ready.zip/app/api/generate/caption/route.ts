import { chat } from '@/lib/ai';
export async function POST(req: Request) {
  const { mood = 'שקט', interests = ['טיולים'], firstName = 'אני' } = await req.json();
  const system = 'את/ה כותב/ת כותרות קצרות ומקוריות בעברית לפוסטים חברתיים. קצר, טבעי, לא קיטשי.';
  const user = `שם פרטי: ${firstName}\nמצב רוח: ${mood}\nתחומי עניין: ${Array.isArray(interests)?interests.join(', '):interests}\nהנחיה: כותרת אחת בלבד (עד 18 מילים), עברית, בלי אימוג'ים.`;
  const text = await chat(system, user);
  return Response.json({ ok: true, text });
}
