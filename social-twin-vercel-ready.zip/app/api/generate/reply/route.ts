import { chat } from '@/lib/ai';
export async function POST(req: Request) {
  const { style = 'חם', firstName = 'אני', toText = '' } = await req.json();
  const system = 'את/ה מנסח/ת תגובות קצרות בעברית, אנושיות ובהירות, לפי סגנון.';
  const user = `שם פרטי: ${firstName}\nסגנון: ${style}\nטקסט שאליו מגיבים: ${toText}\nהנחיה: תגובה אחת בלבד (עד 22 מילים), עברית, בלי אימוג'ים.`;
  const text = await chat(system, user);
  return Response.json({ ok: true, text });
}
