import { prisma } from '@/lib/db';
import { auth } from '@/lib/auth';

export async function POST(req: Request) {
  const session = await auth();
  if (!session?.user) return new Response('unauthorized', { status: 401 });
  const { caption, imageUrl } = await req.json();
  if (!caption) return new Response('bad', { status: 400 });
  const post = await prisma.post.create({ data: { ownerId: (session as any).userId, caption, imageUrl: imageUrl || null } });
  const owner = await prisma.user.findUnique({ where: { id: (session as any).userId } });
  return Response.json({ ...post, ownerName: owner?.name || 'אני' });
}
