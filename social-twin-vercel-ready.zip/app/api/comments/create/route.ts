import { prisma } from '@/lib/db';
import { auth } from '@/lib/auth';

export async function POST(req: Request) {
  const session = await auth();
  if (!session?.user) return new Response('unauthorized', { status: 401 });
  const { postId, text, byTwin } = await req.json();
  if (!postId || !text) return new Response('bad', { status: 400 });
  const c = await prisma.comment.create({ data: { postId, text, byTwin: !!byTwin, authorId: (session as any).userId } });
  const author = await prisma.user.findUnique({ where: { id: (session as any).userId } });
  return Response.json({ ...c, authorName: author?.name || 'אני' });
}
